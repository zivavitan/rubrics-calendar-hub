import express from 'express';
import dutiesRouter from './routes/duties';
import cors from 'cors';

const app = express();
const port = 4000;

app.use(cors());
app.use(express.json());
app.use('/api/duties', dutiesRouter);

app.listen(port, () => {
  console.log(`Backend server is running on http://localhost:${port}`);
});