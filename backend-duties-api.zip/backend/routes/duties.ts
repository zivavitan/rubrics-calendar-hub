import express from 'express';
import pool from '../db/client';

const router = express.Router();

router.get('/', async (req, res) => {
  const { date } = req.query;
  try {
    const result = await pool.query(
      \`SELECT d.*, u.id as user_id, u.name, u.email, u.phone, u.role
       FROM duties d
       JOIN users u ON d.user_id = u.id
       WHERE d.date = $1\`,
      [date]
    );
    const duties = result.rows.map(row => ({
      id: row.id,
      userId: row.user_id,
      type: row.type,
      date: row.date,
      user: {
        id: row.user_id,
        name: row.name,
        email: row.email,
        phone: row.phone,
        role: row.role,
      }
    }));
    res.json(duties);
  } catch (error) {
    console.error('Error fetching duties:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.post('/', async (req, res) => {
  const { userId, type, date } = req.body;
  try {
    const result = await pool.query(
      'INSERT INTO duties (user_id, type, date) VALUES ($1, $2, $3) RETURNING id',
      [userId, type, date]
    );
    res.json({ id: result.rows[0].id });
  } catch (error) {
    console.error('Error adding duty:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.delete('/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query('DELETE FROM duties WHERE id = $1', [id]);
    res.status(204).send();
  } catch (error) {
    console.error('Error deleting duty:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;